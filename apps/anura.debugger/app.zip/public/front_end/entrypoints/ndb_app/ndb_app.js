import"../shell/shell.js";import*as m from"../main/main.js";new m.MainImpl.MainImpl;
