# Ensure that the `Attribution-Reporting-Register-Source` header is valid

This page tried to register a source using the Attribution Reporting API but
failed because an `Attribution-Reporting-Register-Source` response header was
invalid.
