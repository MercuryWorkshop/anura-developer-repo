# getUserInfo() is disabled because the IDP Sign-In Status is signed-out.
