# Third-party websites are allowed to read cookies on this page

One or more websites are allowed to bypass user settings to read third-party cookies on this page. Chrome no longer supports third-party cookies and web developers should take steps to remove these reads without disrupting user experience. To forcefully block these third-party cookies, update [user settings](https://support.google.com/chrome/answer/95647).
