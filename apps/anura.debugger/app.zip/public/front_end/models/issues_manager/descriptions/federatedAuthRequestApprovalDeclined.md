# User declined the sign-in attempt.
