# getUserInfo() caller is not same origin as the config URL.
