# Third-party websites are allowed to set cookies on this page

One or more websites are allowed to bypass user settings to set third-party cookies on this page. Chrome no longer supports third-party cookies and web developers should take steps to remove these sets without disrupting user experience. To forcefully block these third-party cookies, update [user settings](https://support.google.com/chrome/answer/95647).
