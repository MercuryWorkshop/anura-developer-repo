# Provider's client metadata is invalid.
