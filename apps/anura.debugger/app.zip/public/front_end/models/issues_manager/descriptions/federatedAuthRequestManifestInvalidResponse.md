# Provider's FedCM manifest configuration is invalid.
