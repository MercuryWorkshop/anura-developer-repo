# getUserInfo() failed because the config URL is not potentially trustworthy.
