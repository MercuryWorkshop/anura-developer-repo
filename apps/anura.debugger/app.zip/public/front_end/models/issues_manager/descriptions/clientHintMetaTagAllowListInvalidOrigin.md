# Client Hint meta tag contained invalid origin

Items in the delegate-ch meta tag allow list must be valid origins.
No special values (e.g. self, none, and *) are permitted.
