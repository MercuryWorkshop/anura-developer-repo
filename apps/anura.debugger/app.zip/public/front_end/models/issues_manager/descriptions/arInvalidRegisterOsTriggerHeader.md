# Ensure that the `Attribution-Reporting-Register-OS-Trigger` header is valid

This page tried to register an OS trigger using the Attribution Reporting API
but failed because an `Attribution-Reporting-Register-OS-Trigger` response
header was invalid.
