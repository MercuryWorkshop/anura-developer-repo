# Only one navigator.credentials.get request may be outstanding at one time.
