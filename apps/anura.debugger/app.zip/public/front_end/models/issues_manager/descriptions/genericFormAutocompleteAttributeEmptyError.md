# Incorrect use of autocomplete attribute

A form field's `autocomplete` attribute is empty. This might prevent the browser from correctly autofilling the form.

To fix this issue, provide a valid `autocomplete` value.
