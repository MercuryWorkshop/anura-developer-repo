# getUserInfo() failed because the user has not yet used FedCM on this site with the provided IDP.
