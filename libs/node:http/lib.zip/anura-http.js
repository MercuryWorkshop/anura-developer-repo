// Copyright Joyent, Inc. and other Node contributors.
//
// Permission is hereby granted, free of charge, to any person obtaining a
// copy of this software and associated documentation files (the
// "Software"), to deal in the Software without restriction, including
// without limitation the rights to use, copy, modify, merge, publish,
// distribute, sublicense, and/or sell copies of the Software, and to permit
// persons to whom the Software is furnished to do so, subject to the
// following conditions:
//
// The above copyright notice and this permission notice shall be included
// in all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
// OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN
// NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
// DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
// OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE
// USE OR OTHER DEALINGS IN THE SOFTWARE.

'use strict';

var R = typeof Reflect === 'object' ? Reflect : null
var ReflectApply = R && typeof R.apply === 'function'
  ? R.apply
  : function ReflectApply(target, receiver, args) {
    return Function.prototype.apply.call(target, receiver, args);
  }

var ReflectOwnKeys
if (R && typeof R.ownKeys === 'function') {
  ReflectOwnKeys = R.ownKeys
} else if (Object.getOwnPropertySymbols) {
  ReflectOwnKeys = function ReflectOwnKeys(target) {
    return Object.getOwnPropertyNames(target)
      .concat(Object.getOwnPropertySymbols(target));
  };
} else {
  ReflectOwnKeys = function ReflectOwnKeys(target) {
    return Object.getOwnPropertyNames(target);
  };
}

function ProcessEmitWarning(warning) {
  if (console && console.warn) console.warn(warning);
}

var NumberIsNaN = Number.isNaN || function NumberIsNaN(value) {
  return value !== value;
}

function EventEmitter() {
  EventEmitter.init.call(this);
}

// Backwards-compat with node 0.10.x
EventEmitter.EventEmitter = EventEmitter;

EventEmitter.prototype._events = undefined;
EventEmitter.prototype._eventsCount = 0;
EventEmitter.prototype._maxListeners = undefined;

// By default EventEmitters will print a warning if more than 10 listeners are
// added to it. This is a useful default which helps finding memory leaks.
var defaultMaxListeners = 10;

function checkListener(listener) {
  if (typeof listener !== 'function') {
    throw new TypeError('The "listener" argument must be of type Function. Received type ' + typeof listener);
  }
}

Object.defineProperty(EventEmitter, 'defaultMaxListeners', {
  enumerable: true,
  get: function() {
    return defaultMaxListeners;
  },
  set: function(arg) {
    if (typeof arg !== 'number' || arg < 0 || NumberIsNaN(arg)) {
      throw new RangeError('The value of "defaultMaxListeners" is out of range. It must be a non-negative number. Received ' + arg + '.');
    }
    defaultMaxListeners = arg;
  }
});

EventEmitter.init = function() {

  if (this._events === undefined ||
      this._events === Object.getPrototypeOf(this)._events) {
    this._events = Object.create(null);
    this._eventsCount = 0;
  }

  this._maxListeners = this._maxListeners || undefined;
};

// Obviously not all Emitters should be limited to 10. This function allows
// that to be increased. Set to zero for unlimited.
EventEmitter.prototype.setMaxListeners = function setMaxListeners(n) {
  if (typeof n !== 'number' || n < 0 || NumberIsNaN(n)) {
    throw new RangeError('The value of "n" is out of range. It must be a non-negative number. Received ' + n + '.');
  }
  this._maxListeners = n;
  return this;
};

function _getMaxListeners(that) {
  if (that._maxListeners === undefined)
    return EventEmitter.defaultMaxListeners;
  return that._maxListeners;
}

EventEmitter.prototype.getMaxListeners = function getMaxListeners() {
  return _getMaxListeners(this);
};

EventEmitter.prototype.emit = function emit(type) {
  var args = [];
  for (var i = 1; i < arguments.length; i++) args.push(arguments[i]);
  var doError = (type === 'error');

  var events = this._events;
  if (events !== undefined)
    doError = (doError && events.error === undefined);
  else if (!doError)
    return false;

  // If there is no 'error' event listener then throw.
  if (doError) {
    var er;
    if (args.length > 0)
      er = args[0];
    if (er instanceof Error) {
      // Note: The comments on the `throw` lines are intentional, they show
      // up in Node's output if this results in an unhandled exception.
      throw er; // Unhandled 'error' event
    }
    // At least give some kind of context to the user
    var err = new Error('Unhandled error.' + (er ? ' (' + er.message + ')' : ''));
    err.context = er;
    throw err; // Unhandled 'error' event
  }

  var handler = events[type];

  if (handler === undefined)
    return false;

  if (typeof handler === 'function') {
    ReflectApply(handler, this, args);
  } else {
    var len = handler.length;
    var listeners = arrayClone(handler, len);
    for (var i = 0; i < len; ++i)
      ReflectApply(listeners[i], this, args);
  }

  return true;
};

function _addListener(target, type, listener, prepend) {
  var m;
  var events;
  var existing;

  checkListener(listener);

  events = target._events;
  if (events === undefined) {
    events = target._events = Object.create(null);
    target._eventsCount = 0;
  } else {
    // To avoid recursion in the case that type === "newListener"! Before
    // adding it to the listeners, first emit "newListener".
    if (events.newListener !== undefined) {
      target.emit('newListener', type,
                  listener.listener ? listener.listener : listener);

      // Re-assign `events` because a newListener handler could have caused the
      // this._events to be assigned to a new object
      events = target._events;
    }
    existing = events[type];
  }

  if (existing === undefined) {
    // Optimize the case of one listener. Don't need the extra array object.
    existing = events[type] = listener;
    ++target._eventsCount;
  } else {
    if (typeof existing === 'function') {
      // Adding the second element, need to change to array.
      existing = events[type] =
        prepend ? [listener, existing] : [existing, listener];
      // If we've already got an array, just append.
    } else if (prepend) {
      existing.unshift(listener);
    } else {
      existing.push(listener);
    }

    // Check for listener leak
    m = _getMaxListeners(target);
    if (m > 0 && existing.length > m && !existing.warned) {
      existing.warned = true;
      // No error code for this since it is a Warning
      // eslint-disable-next-line no-restricted-syntax
      var w = new Error('Possible EventEmitter memory leak detected. ' +
                          existing.length + ' ' + String(type) + ' listeners ' +
                          'added. Use emitter.setMaxListeners() to ' +
                          'increase limit');
      w.name = 'MaxListenersExceededWarning';
      w.emitter = target;
      w.type = type;
      w.count = existing.length;
      ProcessEmitWarning(w);
    }
  }

  return target;
}

EventEmitter.prototype.addListener = function addListener(type, listener) {
  return _addListener(this, type, listener, false);
};

EventEmitter.prototype.on = EventEmitter.prototype.addListener;

EventEmitter.prototype.prependListener =
    function prependListener(type, listener) {
      return _addListener(this, type, listener, true);
    };

function onceWrapper() {
  if (!this.fired) {
    this.target.removeListener(this.type, this.wrapFn);
    this.fired = true;
    if (arguments.length === 0)
      return this.listener.call(this.target);
    return this.listener.apply(this.target, arguments);
  }
}

function _onceWrap(target, type, listener) {
  var state = { fired: false, wrapFn: undefined, target: target, type: type, listener: listener };
  var wrapped = onceWrapper.bind(state);
  wrapped.listener = listener;
  state.wrapFn = wrapped;
  return wrapped;
}

EventEmitter.prototype.once = function once(type, listener) {
  checkListener(listener);
  this.on(type, _onceWrap(this, type, listener));
  return this;
};

EventEmitter.prototype.prependOnceListener =
    function prependOnceListener(type, listener) {
      checkListener(listener);
      this.prependListener(type, _onceWrap(this, type, listener));
      return this;
    };

// Emits a 'removeListener' event if and only if the listener was removed.
EventEmitter.prototype.removeListener =
    function removeListener(type, listener) {
      var list, events, position, i, originalListener;

      checkListener(listener);

      events = this._events;
      if (events === undefined)
        return this;

      list = events[type];
      if (list === undefined)
        return this;

      if (list === listener || list.listener === listener) {
        if (--this._eventsCount === 0)
          this._events = Object.create(null);
        else {
          delete events[type];
          if (events.removeListener)
            this.emit('removeListener', type, list.listener || listener);
        }
      } else if (typeof list !== 'function') {
        position = -1;

        for (i = list.length - 1; i >= 0; i--) {
          if (list[i] === listener || list[i].listener === listener) {
            originalListener = list[i].listener;
            position = i;
            break;
          }
        }

        if (position < 0)
          return this;

        if (position === 0)
          list.shift();
        else {
          spliceOne(list, position);
        }

        if (list.length === 1)
          events[type] = list[0];

        if (events.removeListener !== undefined)
          this.emit('removeListener', type, originalListener || listener);
      }

      return this;
    };

EventEmitter.prototype.off = EventEmitter.prototype.removeListener;

EventEmitter.prototype.removeAllListeners =
    function removeAllListeners(type) {
      var listeners, events, i;

      events = this._events;
      if (events === undefined)
        return this;

      // not listening for removeListener, no need to emit
      if (events.removeListener === undefined) {
        if (arguments.length === 0) {
          this._events = Object.create(null);
          this._eventsCount = 0;
        } else if (events[type] !== undefined) {
          if (--this._eventsCount === 0)
            this._events = Object.create(null);
          else
            delete events[type];
        }
        return this;
      }

      // emit removeListener for all listeners on all events
      if (arguments.length === 0) {
        var keys = Object.keys(events);
        var key;
        for (i = 0; i < keys.length; ++i) {
          key = keys[i];
          if (key === 'removeListener') continue;
          this.removeAllListeners(key);
        }
        this.removeAllListeners('removeListener');
        this._events = Object.create(null);
        this._eventsCount = 0;
        return this;
      }

      listeners = events[type];

      if (typeof listeners === 'function') {
        this.removeListener(type, listeners);
      } else if (listeners !== undefined) {
        // LIFO order
        for (i = listeners.length - 1; i >= 0; i--) {
          this.removeListener(type, listeners[i]);
        }
      }

      return this;
    };

function _listeners(target, type, unwrap) {
  var events = target._events;

  if (events === undefined)
    return [];

  var evlistener = events[type];
  if (evlistener === undefined)
    return [];

  if (typeof evlistener === 'function')
    return unwrap ? [evlistener.listener || evlistener] : [evlistener];

  return unwrap ?
    unwrapListeners(evlistener) : arrayClone(evlistener, evlistener.length);
}

EventEmitter.prototype.listeners = function listeners(type) {
  return _listeners(this, type, true);
};

EventEmitter.prototype.rawListeners = function rawListeners(type) {
  return _listeners(this, type, false);
};

EventEmitter.listenerCount = function(emitter, type) {
  if (typeof emitter.listenerCount === 'function') {
    return emitter.listenerCount(type);
  } else {
    return listenerCount.call(emitter, type);
  }
};

EventEmitter.prototype.listenerCount = listenerCount;
function listenerCount(type) {
  var events = this._events;

  if (events !== undefined) {
    var evlistener = events[type];

    if (typeof evlistener === 'function') {
      return 1;
    } else if (evlistener !== undefined) {
      return evlistener.length;
    }
  }

  return 0;
}

EventEmitter.prototype.eventNames = function eventNames() {
  return this._eventsCount > 0 ? ReflectOwnKeys(this._events) : [];
};

function arrayClone(arr, n) {
  var copy = new Array(n);
  for (var i = 0; i < n; ++i)
    copy[i] = arr[i];
  return copy;
}

function spliceOne(list, index) {
  for (; index + 1 < list.length; index++)
    list[index] = list[index + 1];
  list.pop();
}

function unwrapListeners(arr) {
  var ret = new Array(arr.length);
  for (var i = 0; i < ret.length; ++i) {
    ret[i] = arr[i].listener || arr[i];
  }
  return ret;
}

function once(emitter, name) {
  return new Promise(function (resolve, reject) {
    function errorListener(err) {
      emitter.removeListener(name, resolver);
      reject(err);
    }

    function resolver() {
      if (typeof emitter.removeListener === 'function') {
        emitter.removeListener('error', errorListener);
      }
      resolve([].slice.call(arguments));
    };

    eventTargetAgnosticAddListener(emitter, name, resolver, { once: true });
    if (name !== 'error') {
      addErrorHandlerIfEventEmitter(emitter, errorListener, { once: true });
    }
  });
}

function addErrorHandlerIfEventEmitter(emitter, handler, flags) {
  if (typeof emitter.on === 'function') {
    eventTargetAgnosticAddListener(emitter, 'error', handler, flags);
  }
}

function eventTargetAgnosticAddListener(emitter, name, listener, flags) {
  if (typeof emitter.on === 'function') {
    if (flags.once) {
      emitter.once(name, listener);
    } else {
      emitter.on(name, listener);
    }
  } else if (typeof emitter.addEventListener === 'function') {
    // EventTarget does not have `error` event semantics like Node
    // EventEmitters, we do not listen for `error` events here.
    emitter.addEventListener(name, function wrapListener(arg) {
      // IE does not have builtin `{ once: true }` support so we
      // have to do it manually.
      if (flags.once) {
        emitter.removeEventListener(name, wrapListener);
      }
      listener(arg);
    });
  } else {
    throw new TypeError('The "emitter" argument must be of type EventEmitter. Received type ' + typeof emitter);
  }
}

export class ClientRequest extends EventEmitter {
  constructor(options, callback) {
    super();

    if (typeof options === "string") {
      options = new URL(options);
    }

    const {
      protocol = "http:",
      hostname = "localhost",
      port,
      path = "/",
      method = "GET",
      headers = {},
      timeout,
    } = options;

    this.url = `${protocol}//${hostname}${port ? `:${port}` : ""}${path}`;
    this.method = method;
    this.headers = headers;
    this.bodyChunks = [];
    this.hasEnded = false;
    this.timeout = null;

    if (callback) {
      this.once("response", callback);
    }

    // Simulate connection events
    setTimeout(() => {
      this.emit("socket", {});
      this.emit("connect");
    }, 0);

    // Handle timeout
    if (timeout) {
      this.timeout = setTimeout(() => {
        if (!this.hasEnded) {
          this.emit("timeout");
          this.abort();
        }
      }, timeout);
    }
  }

  write(chunk) {
    if (this.hasEnded) {
      throw new Error("Cannot write after end.");
    }
    if (typeof chunk === "string") {
      chunk = new TextEncoder().encode(chunk);
    }
    if (!(chunk instanceof Uint8Array)) {
      throw new TypeError("Chunk must be a string or Uint8Array.");
    }
    this.bodyChunks.push(chunk);
  }

  end(chunk = null) {
    if (chunk) {
      this.write(chunk);
    }
    this.hasEnded = true;
    this.emit("finish");

    const body =
      this.bodyChunks.length > 0
        ? new Blob(this.bodyChunks, { type: this.headers["Content-Type"] || "" })
        : undefined;

    anura.net.fetch(this.url, {
      method: this.method,
      headers: this.headers,
      body,
    })
      .then(async (response) => {
        clearTimeout(this.timeout);
        const incomingMessage = new IncomingMessagePolyfill(response);
        this.emit("response", incomingMessage);
        incomingMessage._readResponse();
      })
      .catch((error) => {
        clearTimeout(this.timeout);
        this.emit("error", error);
      });
  }

  abort() {
    this.hasEnded = true;
    this.emit("abort");
    clearTimeout(this.timeout);
  }

  setHeader(name, value) {
    this.headers[name] = value;
  }

  getHeader(name) {
    return this.headers[name] || null;
  }

  removeHeader(name) {
    delete this.headers[name];
  }
}

function httpRequestPolyfill(options, callback) {
  return new ClientRequest(options, callback);
}


class IncomingMessagePolyfill extends EventEmitter {
  constructor(response) {
    super();

    // Response properties
    this.statusCode = response.status;
    this.statusMessage = response.statusText;
    this.httpVersion = "1.1"; // Fetch API uses HTTP/1.1 by default

    // Headers
    this.headers = this._convertHeaders(response.headers);
    this.rawHeaders = this._convertRawHeaders(response.headers);

    // Stream-related properties
    this._response = response;
    this._reader = response.body ? response.body.getReader() : null;
    this._consuming = false;
    this._encoding = null; // Default: no encoding (emit raw Uint8Array)
    this._paused = false; // Tracks if the stream is paused

    // Node.js-specific properties
    this.complete = false;
    this.aborted = false;
    this.upgrade = false;

    // Simulate other Node.js request/response metadata
    this.url = response.url || ""; // Fetch's Response includes the URL
    this.method = response.method; // Default for Fetch responses (can be adjusted if needed)
  }

  _convertHeaders(headers) {
    const result = {};
    for (const [key, value] of headers.entries()) {
      result[key.toLowerCase()] = value;
    }
    return result;
  }

  _convertRawHeaders(headers) {
    const rawHeaders = [];
    for (const [key, value] of headers.entries()) {
      rawHeaders.push(key, value);
    }
    return rawHeaders;
  }

  _readResponse() {
    if (!this._reader) {
      this.emit("end");
      return;
    }

    this._consuming = true;

    const read = () => {
      if (this._paused) return; // Stop reading if paused

      this._reader.read().then(({ done, value }) => {
        if (done) {
          this._consuming = false;
          this.emit("end");
          return;
        }

        if (this._encoding) {
          // Convert Uint8Array to a string using the specified encoding
          const decoder = new TextDecoder(this._encoding);
          value = decoder.decode(value);
        }

        this.emit("data", value);
        if (!this._paused) {
          read();
        }
      });
    };

    read();
  }

  setEncoding(encoding) {
    this._encoding = encoding || "utf-8"; // Default to UTF-8 if encoding is null
  }

  pause() {
    this._paused = true;
  }

  resume() {
    if (this._paused) {
      this._paused = false;
      if (this._consuming) {
        this._readResponse(); // Resume reading
      }
    }
  }

  destroy() {
    if (this._reader) {
      this._reader.cancel();
    }
    this.emit("close");
  }
}



class ServerResponsePolyfill {
    constructor() {
      // EventEmitter-like properties
      this._events = {};
      this._eventsCount = 0;
      this._maxListeners = undefined;
  
      // Internal response properties
      this.outputData = [];
      this.outputSize = 0;
      this.writable = true;
      this.destroyed = false;
      this._last = false;
      this.chunkedEncoding = false;
      this.shouldKeepAlive = true;
      this.maxRequestsOnConnectionReached = false;
      this._defaultKeepAlive = true;
      this.useChunkedEncodingByDefault = true;
      this.sendDate = true;
      this._removedConnection = false;
      this._removedContLen = false;
      this._removedTE = false;
      this.strictContentLength = false;
      this._contentLength = null;
      this._hasBody = true;
      this._trailer = "";
      this.finished = false;
      this._headerSent = false;
      this._closed = false;
      this._header = null;
      this._keepAliveTimeout = 0;
      this._onPendingData = null;
      this.req = null;
      this._sent100 = false;
      this._expect_continue = false;
      this._maxRequestsPerSocket = null;
  
      // Custom properties for tracking response data
      this._statusCode = 200;
      this._statusMessage = "OK";
      this._headers = {};
      this._body = [];
      this.headersSent = false;
      this.writableEnded = false;
    }
  
    // Set header
    setHeader(name, value) {
      if (this.headersSent) {
        throw new Error("Cannot set headers after they are sent.");
      }
      this._headers[name.toLowerCase()] = value;
    }
  
    // Get header
    getHeader(name) {
      return this._headers[name.toLowerCase()] || null;
    }
  
    // Remove header
    removeHeader(name) {
      if (this.headersSent) {
        throw new Error("Cannot remove headers after they are sent.");
      }
      delete this._headers[name.toLowerCase()];
    }
  
    // Write headers
    writeHead(statusCode, statusMessageOrHeaders, headers) {
      this._statusCode = statusCode;
      if (typeof statusMessageOrHeaders === "string") {
        this._statusMessage = statusMessageOrHeaders;
        if (headers) {
          this._headers = { ...this._headers, ...headers };
        }
      } else if (typeof statusMessageOrHeaders === "object") {
        this._headers = { ...this._headers, ...statusMessageOrHeaders };
      }
      this.headersSent = true;
      this._headerSent = true;
    }
  
    // Write response body
    write(chunk, encoding = "utf-8") {
      if (typeof chunk === "string") {
        chunk = new TextEncoder().encode(chunk);
      } else if (!(chunk instanceof Uint8Array)) {
        throw new TypeError("Chunk must be a string or Uint8Array.");
      }
      this._body.push(chunk);
      this.outputSize += chunk.length;
    }
  
    // End the response
    end(chunk = null, encoding = "utf-8") {
      if (chunk) {
        this.write(chunk, encoding);
      }
      if (this.endCallBack) {
        this.endCallBack();
      }
      this.finished = true;
      this.writableEnded = true;
      this._last = true;
    }
  
    // Add trailers
    addTrailers(trailers) {
      this._trailer = trailers;
    }
  
    // Destroy the response
    destroy() {
      this.destroyed = true;
      this.writable = false;
    }
  
    // Convert to browser-compatible Response object
    toBrowserResponse() {
      const body = this._body.length
        ? new Blob(this._body, { type: "application/octet-stream" })
        : null;
      return new Response(body, {
        status: this._statusCode,
        statusText: this._statusMessage,
        headers: this._headers,
      });
    }
}

class HttpServer extends EventEmitter {
    constructor() {
        super();
    }
    listen(port) {
        anura.net.loopback.set(port, async (req)=> {
            req = new IncomingMessagePolyfill(req)
            const res = new ServerResponsePolyfill()
            const ended = new Promise((resolve,reject)=> {
                res.endCallBack = () => {
                    resolve(res.toBrowserResponse());
                }
            });
            this.emit("request", req, res);
            return await ended;
        })
    }
}

function httpGetPolyfill(options, callback) {
  if (typeof options === "string") {
    options = new URL(options);
  }
  options.method = "GET";
  const req = httpRequestPolyfill(options, callback);
  req.end();

  return req;
}

const http = {
    "createServer": function(callback) {
        const server = new HttpServer();
        if (callback) {
            server.on("request", callback)
        }
        return server;
    },
    "request": httpRequestPolyfill,
    "get": httpGetPolyfill,
    "WebSocket": anura.net.WebSocket,
    ClientRequest
}
export const createServer = http.createServer;
export const request = http.request;
export const get = http.get;
export const WebSocket = http.WebSocket; // I hate defining a WebSocket here but I dont know how else to do this
export const ServerResponse = ServerResponsePolyfill;

export default http;
